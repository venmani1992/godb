import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AgGridModule } from 'ag-grid-angular';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatGridListModule} from '@angular/material/grid-list';
import { OrderbookComponent } from './components/orderbook/orderbook.component';
import { AvailablityComponent } from './components/availablity/availablity.component';
import { GridpageComponent } from './components/gridpage/gridpage.component';
import { DtcpositionComponent } from './components/dtcposition/dtcposition.component';
// import {MatButtonModule} from '@angular/material/button';
import { GoldentemplateComponent } from './components/goldentemplate/goldentemplate.component';
import { MatInputModule, MatButtonModule, MatIconModule, MatSelectModule,MatCardModule, MatFormFieldModule, MatTableModule } from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { GridsterModule } from 'angular-gridster2';
@NgModule({
  declarations: [AppComponent, OrderbookComponent, AvailablityComponent, GridpageComponent, DtcpositionComponent, GoldentemplateComponent],
  imports: [
    AppRoutingModule,
    BrowserModule,MatToolbarModule,MatGridListModule,
    AgGridModule.withComponents([]),
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    FormsModule,
    MatSelectModule,
    MatCardModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatTableModule,
    HttpClientModule,
    BrowserAnimationsModule,
    GridsterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}