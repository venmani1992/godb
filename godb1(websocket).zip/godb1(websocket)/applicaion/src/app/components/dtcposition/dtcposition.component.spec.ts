import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DtcpositionComponent } from './dtcposition.component';

describe('DtcpositionComponent', () => {
  let component: DtcpositionComponent;
  let fixture: ComponentFixture<DtcpositionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DtcpositionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DtcpositionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
