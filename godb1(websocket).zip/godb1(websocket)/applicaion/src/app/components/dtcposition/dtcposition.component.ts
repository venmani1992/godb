import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ServicesService } from '../../services.service';
import { Observable, BehaviorSubject } from 'rxjs';
let socket = new WebSocket("ws://localhost:80/");
socket.onclose = function (event) {
  if (event.wasClean) {
    alert(`[close] Connection closed cleanly, code=${event.code} reason=${event.reason}`);
  } else {
    // e.g. server process killed or network down
    // event.code is usually 1006 in this case
    alert('[close] Connection died');
  }
};

socket.onerror = function (error) {
  let error1: any = {}; error1 = error;
  alert(`[error] ${error1.message}`);
};
@Component({
  selector: 'app-dtcposition',
  templateUrl: './dtcposition.component.html',
  styleUrls: ['./dtcposition.component.sass']
})
export class DtcpositionComponent implements OnInit {



  model: any = {};
  //submitted = false;
  //registerForm: FormGroup;
  dataSource: any = [];
  // tt: any ={};
  //dataSource = new BehaviorSubject([]);
  displayedColumns: string[] = ['company_name', 'price'];
  constructor(private servicesService: ServicesService) { }

  ngOnInit() {
    // alert();
    // this.callfun();
    // alert();
  }
  //  moreData() {
  //   let text = '';
  //   const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

  //   for (let i = 0; i < 5; i++) {
  //     text += possible.charAt(Math.floor(Math.random() * possible.length));
  //   }

  //   return text;
  // }
  callfun() {
    this.servicesService.getCustomerById().subscribe(data1 => {
      console.log(data1);
      let data: any = {};
      data = data1
      this.dataSource = data.data;
      //  this.dataSource.unshift(this.model);
      console.log(this.dataSource);
    })
  }
  onSubmit(data1) {
    console.log(this.model);
    let jsonval = { company: data1, price: 1 };
    let socket = new WebSocket("ws://localhost:80/");
    socket.onopen = function (e) {
      alert("[open] Connection established");
      alert("Sending to server");
      // socket.send("My name is John");
      let count = 0;
      setInterval(() => {
        if (socket.bufferedAmount == 0) {
          count = count + 1;
          socket.send(`Company=${data1} Price=${count}`);
        }
      }, 5000);
      return false;
    };

    /*socket.onmessage = function(event) {
      alert(`[message] Data received from server: ${event.data}`);
      let message = event.data;

      let messageElem = document.createElement('div');
      messageElem.textContent = message;
      document.getElementById('messages').prepend(messageElem);
    };*/
    socket.onmessage = e => {
      console.log(e.data);
      // this.tt = e.data;
      let message = e.data;

      let messageElem = document.createElement('div');
      messageElem.textContent = message;
      document.getElementById('messages').appendChild(messageElem);

    }
  }

}
