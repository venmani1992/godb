import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ServicesService } from '../../services.service';
import { Observable, BehaviorSubject } from 'rxjs';
@Component({
  selector: 'app-availablity',
  templateUrl: './availablity.component.html',
  styleUrls: ['./availablity.component.sass']
})
export class AvailablityComponent implements OnInit {

  model: any = {};
   dataSource: any = [];
  //dataSource = new BehaviorSubject([]);
  displayedColumns: string[] = ['sno','company_name', 'industry', 'market_cap_size'];
  constructor(private formBuilder: FormBuilder,
  private servicesService: ServicesService) { }

  ngOnInit() {
    this.callfun();
  }
  callfun() {
    this.servicesService.getCustomerById().subscribe(data1 => {
      console.log(data1);
      let data: any ={};
      data = data1
      this.dataSource = data.data;
    //  this.dataSource.unshift(this.model);
      console.log(this.dataSource);
    })
  }
  onSubmit() {
     this.dataSource = this.dataSource.concat([{company_name: this.model.company_name , industry: this.model.industry ,market_cap_size: this.model.market_cap_size}]);
      this.model={};
       console.log(this.dataSource);
       
   }

}
