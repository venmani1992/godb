import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GoldentemplateComponent } from './goldentemplate.component';

describe('GoldentemplateComponent', () => {
  let component: GoldentemplateComponent;
  let fixture: ComponentFixture<GoldentemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GoldentemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GoldentemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
