import { Component, OnInit } from '@angular/core';

import * as $ from 'jquery';
import * as GoldenLayout from 'golden-layout';

@Component({
  selector: 'app-goldentemplate',
  templateUrl: './goldentemplate.component.html',
  styleUrls: ['./goldentemplate.component.sass']
})
export class GoldentemplateComponent implements OnInit {
  title = 'demo';
 
  ngOnInit() {
      $(document).ready(function () {
          //$("#gs").val("Thanks Lord Ganesh Shiva");
          //loadLayout();
          var config = {
              content: [{
                  type: 'row',
                  content: [
                      {
                          type: 'component',
                          componentName: 'example',
                          componentState: { text: 'Component 1' }
                      },
                      {
                          type: 'component',
                          componentName: 'example',
                          componentState: { text: 'Component 2' }
                      },
                      {
                          type: 'component',
                          componentName: 'example',
                          componentState: { text: 'Component 3' }
                      }
                  ]
              }]
          };

          var myLayout = new GoldenLayout(config);

          myLayout.registerComponent('example', function (container, state) {
              container.getElement().html(`<app-availablity></app-availablity>`);
              
          });

          myLayout.init();

      });
  }

}
