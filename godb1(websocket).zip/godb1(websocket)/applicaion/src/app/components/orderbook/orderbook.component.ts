import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orderbook',
  templateUrl: './orderbook.component.html',
  styleUrls: ['./orderbook.component.sass']
})
export class OrderbookComponent implements OnInit {

    title = 'app';

    columnDefs = [
        {headerName: 'Make', field: 'make', sortable: true, filter: true , checkboxSelection: true, width: 300,suppressSizeToFit: false},
        {headerName: 'Model', field: 'model', sortable: true, filter: true , width: 300,suppressSizeToFit: false},
        {headerName: 'Price', field: 'price', sortable: true, filter: true,   width: 300 ,suppressSizeToFit: false}
    ];

    rowData = [
        { make: 'Toyota', model: 'Celica', price: 35000 },
        { make: 'Ford', model: 'Mondeo', price: 32000 },
        { make: 'Porsche', model: 'Boxter', price: 72000 }
    ];
  constructor() { }

  ngOnInit() {
  }

}
