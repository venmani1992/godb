import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OrderbookComponent } from './components/orderbook/orderbook.component';
import { AvailablityComponent } from './components/availablity/availablity.component';
import { GridpageComponent } from './components/gridpage/gridpage.component';
import { DtcpositionComponent } from './components/dtcposition/dtcposition.component';
import { GoldentemplateComponent } from './components/goldentemplate/goldentemplate.component';


const routes: Routes = [
  { path: 'orderbook', component: OrderbookComponent },
  { path: 'availablity', component: AvailablityComponent },
  { path: 'dtcposition', component: DtcpositionComponent },
  { path: 'goldentemplate', component: GoldentemplateComponent },
  
  { path: 'grid', component: GridpageComponent },
  { path: '',  component: GridpageComponent  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
