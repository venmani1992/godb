import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ServicesService {
  apiURL: string = 'http://10.12.121.60:9080';

  constructor(private httpClient: HttpClient) { }
  getCustomerById(){
    return this.httpClient.get(this.apiURL + '/emapi/api/v2/info/s_company_list?company=ABC');
  }
}
